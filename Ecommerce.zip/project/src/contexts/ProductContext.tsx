import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product } from '../types';
import {
  initializeProducts,
  getAllProducts,
  getProductById,
  addProduct,
  updateProduct,
  deleteProduct,
  searchProducts
} from '../utils/productService';

interface ProductContextType {
  products: Product[];
  loading: boolean;
  error: string | null;
  selectedProducts: Product[];
  addToComparison: (productId: string) => void;
  removeFromComparison: (productId: string) => void;
  clearComparison: () => void;
  getProduct: (id: string) => Product | undefined;
  createProduct: (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>) => Promise<Product>;
  editProduct: (id: string, updates: Partial<Product>) => Promise<Product | null>;
  removeProduct: (id: string) => Promise<boolean>;
  searchForProducts: (query: string) => void;
  clearError: () => void;
}

const ProductContext = createContext<ProductContextType | undefined>(undefined);

export const ProductProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedProducts, setSelectedProducts] = useState<Product[]>([]);

  useEffect(() => {
    initializeProducts();
    loadProducts();
  }, []);

  const loadProducts = () => {
    try {
      const productList = getAllProducts();
      setProducts(productList);
    } catch (err) {
      setError('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const getProduct = (id: string): Product | undefined => {
    return getProductById(id);
  };

  const createProduct = async (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Promise<Product> => {
    try {
      setLoading(true);
      setError(null);
      
      const newProduct = addProduct(product);
      loadProducts();
      
      return newProduct;
    } catch (err) {
      setError('Failed to create product');
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const editProduct = async (id: string, updates: Partial<Product>): Promise<Product | null> => {
    try {
      setLoading(true);
      setError(null);
      
      const updated = updateProduct(id, updates);
      loadProducts();
      
      if (!updated) {
        setError('Product not found');
      }
      
      return updated;
    } catch (err) {
      setError('Failed to update product');
      return null;
    } finally {
      setLoading(false);
    }
  };

  const removeProduct = async (id: string): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);
      
      const success = deleteProduct(id);
      loadProducts();
      
      if (!success) {
        setError('Product not found');
      }
      
      // Also remove from comparison if present
      setSelectedProducts(prev => prev.filter(p => p.id !== id));
      
      return success;
    } catch (err) {
      setError('Failed to delete product');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const searchForProducts = (query: string) => {
    try {
      setLoading(true);
      setError(null);
      
      const results = searchProducts(query);
      setProducts(results);
    } catch (err) {
      setError('Failed to search products');
    } finally {
      setLoading(false);
    }
  };

  const addToComparison = (productId: string) => {
    const product = getProductById(productId);
    if (!product) return;
    
    // Limit to 3 products for comparison
    if (selectedProducts.length >= 3) {
      setError('You can compare up to 3 products at a time');
      return;
    }
    
    // Check if already selected
    if (selectedProducts.some(p => p.id === productId)) {
      return;
    }
    
    setSelectedProducts(prev => [...prev, product]);
  };

  const removeFromComparison = (productId: string) => {
    setSelectedProducts(prev => prev.filter(p => p.id !== productId));
  };

  const clearComparison = () => {
    setSelectedProducts([]);
  };

  const clearError = () => {
    setError(null);
  };

  return (
    <ProductContext.Provider
      value={{
        products,
        loading,
        error,
        selectedProducts,
        addToComparison,
        removeFromComparison,
        clearComparison,
        getProduct,
        createProduct,
        editProduct,
        removeProduct,
        searchForProducts,
        clearError
      }}
    >
      {children}
    </ProductContext.Provider>
  );
};

export const useProducts = (): ProductContextType => {
  const context = useContext(ProductContext);
  if (context === undefined) {
    throw new Error('useProducts must be used within a ProductProvider');
  }
  return context;
};