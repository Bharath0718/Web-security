import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types';
import { 
  initializeUsers, 
  registerUser, 
  loginUser, 
  logoutUser, 
  isAuthenticated, 
  getCurrentUser, 
  isAdmin 
} from '../utils/auth';

interface AuthContextType {
  user: { userId: string; email: string; role: string } | null;
  loading: boolean;
  error: string | null;
  login: (email: string, password: string) => Promise<boolean>;
  register: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  isUserAuthenticated: () => boolean;
  isUserAdmin: () => boolean;
  clearError: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<{ userId: string; email: string; role: string } | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    initializeUsers();
    const currentUser = getCurrentUser();
    setUser(currentUser);
    setLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);
      
      const user = await loginUser(email, password);
      
      if (!user) {
        setError('Invalid email or password');
        return false;
      }
      
      setUser(getCurrentUser());
      return true;
    } catch (err) {
      setError('An error occurred during login');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const register = async (email: string, password: string): Promise<boolean> => {
    try {
      setLoading(true);
      setError(null);
      
      const user = await registerUser(email, password);
      
      if (!user) {
        setError('Email already exists');
        return false;
      }
      
      // Auto login after registration
      await loginUser(email, password);
      setUser(getCurrentUser());
      return true;
    } catch (err) {
      setError('An error occurred during registration');
      return false;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    logoutUser();
    setUser(null);
  };

  const isUserAuthenticated = () => {
    return isAuthenticated();
  };

  const isUserAdmin = () => {
    return isAdmin();
  };

  const clearError = () => {
    setError(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        error,
        login,
        register,
        logout,
        isUserAuthenticated,
        isUserAdmin,
        clearError
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};