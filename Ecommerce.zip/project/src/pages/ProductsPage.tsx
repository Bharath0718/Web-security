import React, { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { useProducts } from '../contexts/ProductContext';

const ProductsPage: React.FC = () => {
  const { products, loading, searchForProducts } = useProducts();
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedBrand, setSelectedBrand] = useState<string>('');
  const [priceRange, setPriceRange] = useState<number>(200000);
  const [showFilters, setShowFilters] = useState(false);

  // Get category and search query from URL params
  useEffect(() => {
    const category = searchParams.get('category');
    const query = searchParams.get('q');
    
    if (category) {
      setSelectedCategory(category);
    }
    
    if (query) {
      setSearchQuery(query);
      searchForProducts(query);
    }
  }, [searchParams, searchForProducts]);

  // Get unique categories and brands from products
  const categories = [...new Set(products.map(product => product.category))];
  const brands = [...new Set(products.map(product => product.brand))];

  // Format price in Indian Rupees
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    searchForProducts(searchQuery);
    
    // Update URL params
    const newParams = new URLSearchParams(searchParams);
    if (searchQuery) {
      newParams.set('q', searchQuery);
    } else {
      newParams.delete('q');
    }
    setSearchParams(newParams);
  };

  // Apply category filter
  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category === selectedCategory ? '' : category);
    
    // Update URL params
    const newParams = new URLSearchParams(searchParams);
    if (category && category !== selectedCategory) {
      newParams.set('category', category);
    } else {
      newParams.delete('category');
    }
    setSearchParams(newParams);
  };

  // Apply brand filter
  const handleBrandChange = (brand: string) => {
    setSelectedBrand(brand === selectedBrand ? '' : brand);
  };

  // Filter products based on selected filters
  const filteredProducts = products.filter(product => {
    const matchesCategory = !selectedCategory || product.category === selectedCategory;
    const matchesBrand = !selectedBrand || product.brand === selectedBrand;
    const matchesPrice = product.price <= priceRange;
    
    return matchesCategory && matchesBrand && matchesPrice;
  });

  // Reset all filters
  const resetFilters = () => {
    setSelectedCategory('');
    setSelectedBrand('');
    setPriceRange(200000);
    setSearchQuery('');
    
    // Reset URL params
    setSearchParams({});
  };

  // Toggle filters panel on mobile
  const toggleFilters = () => {
    setShowFilters(!showFilters);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16 pb-12">
      <div className="container mx-auto px-4">
        {/* Page Header */}
        <div className="bg-white rounded-xl shadow-md p-6 mb-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-4">
            {selectedCategory ? `${selectedCategory}` : 'All Products'}
          </h1>
          
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="relative mb-4">
            <input
              type="text"
              placeholder="Search products..."
              className="w-full md:w-2/3 pl-10 pr-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search size={20} className="text-gray-400" />
            </div>
            <button
              type="submit"
              className="md:absolute top-0 right-0 md:right-1/3 mt-2 md:mt-0 w-full md:w-auto px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Search
            </button>
          </form>
          
          {/* Mobile Filter Button */}
          <button
            onClick={toggleFilters}
            className="md:hidden w-full flex items-center justify-center px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            <SlidersHorizontal size={18} className="mr-2" />
            {showFilters ? 'Hide Filters' : 'Show Filters'}
          </button>
        </div>
        
        <div className="flex flex-col md:flex-row gap-6">
          {/* Filters Sidebar */}
          <div 
            className={`${
              showFilters ? 'block' : 'hidden'
            } md:block w-full md:w-1/4 lg:w-1/5 bg-white rounded-xl shadow-md p-6 h-fit`}
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold">Filters</h2>
              <button 
                onClick={resetFilters} 
                className="text-sm text-blue-600 hover:text-blue-800"
              >
                Reset All
              </button>
            </div>
            
            {/* Categories */}
            <div className="mb-6">
              <h3 className="font-medium mb-2">Categories</h3>
              <div className="space-y-1">
                {categories.map(category => (
                  <div key={category} className="flex items-center">
                    <button
                      onClick={() => handleCategoryChange(category)}
                      className={`flex items-center w-full px-2 py-1 rounded-md text-left ${
                        selectedCategory === category
                          ? 'bg-blue-100 text-blue-800'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      <span>{category}</span>
                      {selectedCategory === category && (
                        <X 
                          size={16} 
                          className="ml-auto text-blue-800" 
                        />
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Brands */}
            <div className="mb-6">
              <h3 className="font-medium mb-2">Brands</h3>
              <div className="space-y-1">
                {brands.map(brand => (
                  <div key={brand} className="flex items-center">
                    <button
                      onClick={() => handleBrandChange(brand)}
                      className={`flex items-center w-full px-2 py-1 rounded-md text-left ${
                        selectedBrand === brand
                          ? 'bg-blue-100 text-blue-800'
                          : 'hover:bg-gray-100'
                      }`}
                    >
                      <span>{brand}</span>
                      {selectedBrand === brand && (
                        <X 
                          size={16} 
                          className="ml-auto text-blue-800" 
                        />
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </div>
            
            {/* Price Range */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h3 className="font-medium">Price Range</h3>
                <span className="text-sm text-gray-600">
                  Up to {formatPrice(priceRange)}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="200000"
                step="1000"
                value={priceRange}
                onChange={(e) => setPriceRange(parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{formatPrice(0)}</span>
                <span>{formatPrice(200000)}</span>
              </div>
            </div>
          </div>
          
          {/* Product Grid */}
          <div className="w-full md:w-3/4 lg:w-4/5">
            {loading ? (
              <div className="text-center py-24">
                <div className="animate-spin h-12 w-12 border-t-2 border-b-2 border-blue-600 rounded-full mx-auto"></div>
                <p className="mt-4 text-gray-600">Loading products...</p>
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="bg-white rounded-xl shadow-md p-12 text-center">
                <p className="text-xl text-gray-600 mb-4">No products found</p>
                <p className="text-gray-500 mb-6">
                  Try adjusting your search or filter criteria
                </p>
                <button
                  onClick={resetFilters}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Clear Filters
                </button>
              </div>
            ) : (
              <>
                <div className="mb-4 text-sm text-gray-600">
                  Showing {filteredProducts.length} {filteredProducts.length === 1 ? 'product' : 'products'}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map(product => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsPage;