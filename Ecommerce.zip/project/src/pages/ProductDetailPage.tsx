import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  Star,
  PlusCircle,
  Calendar,
  CheckCircle,
  ArrowLeft,
  Trash2
} from 'lucide-react';
import { useProducts } from '../contexts/ProductContext';
import { useAuth } from '../contexts/AuthContext';
import { Product } from '../types';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { 
    getProduct, 
    addToComparison, 
    selectedProducts, 
    removeProduct, 
    loading 
  } = useProducts();
  const { isUserAdmin } = useAuth();
  const [product, setProduct] = useState<Product | null>(null);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  useEffect(() => {
    if (id) {
      const productData = getProduct(id);
      setProduct(productData || null);
    }
  }, [id, getProduct]);

  // Format price in Indian Rupees
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 pt-24 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin h-12 w-12 border-t-2 border-b-2 border-blue-600 rounded-full mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading product details...</p>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 pt-24">
        <div className="container mx-auto px-4 py-12">
          <div className="bg-white rounded-xl shadow-md p-12 text-center">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">Product Not Found</h1>
            <p className="text-gray-600 mb-8">
              The product you are looking for does not exist or has been removed.
            </p>
            <Link
              to="/products"
              className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <ArrowLeft size={18} className="mr-2" />
              Back to Products
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const handleAddToComparison = () => {
    if (id) {
      addToComparison(id);
    }
  };

  const isSelected = selectedProducts.some(p => p.id === product.id);

  const handleDeleteProduct = async () => {
    if (id) {
      const success = await removeProduct(id);
      if (success) {
        navigate('/products');
      }
    }
  };

  // Convert specification object to an array for rendering
  const specifications = Object.entries(product.specifications).map(([key, value]) => ({
    key: key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1'),
    value,
  }));

  return (
    <div className="min-h-screen bg-gray-50 pt-16 pb-12">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link 
            to="/products" 
            className="inline-flex items-center text-blue-600 hover:text-blue-800"
          >
            <ArrowLeft size={16} className="mr-1" />
            Back to Products
          </Link>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2">
            {/* Product Image */}
            <div className="bg-gray-100 p-8 flex items-center justify-center">
              <img 
                src={product.image} 
                alt={product.name} 
                className="max-w-full max-h-80 object-contain"
              />
            </div>

            {/* Product Info */}
            <div className="p-8">
              <div className="flex flex-col h-full">
                <div>
                  <div className="flex items-center text-sm text-gray-500 mb-2">
                    <span>{product.brand}</span>
                    <span className="mx-2">•</span>
                    <span>{product.category}</span>
                    {isUserAdmin() && (
                      <>
                        <span className="mx-2">•</span>
                        <Link 
                          to={`/admin/products/edit/${product.id}`}
                          className="text-blue-600 hover:text-blue-800"
                        >
                          Edit
                        </Link>
                      </>
                    )}
                  </div>

                  <h1 className="text-3xl font-bold text-gray-800 mb-3">{product.name}</h1>

                  <div className="flex items-center mb-4">
                    <div className="flex items-center bg-blue-50 text-blue-700 px-3 py-1 rounded-full">
                      <Star size={16} className="fill-current text-yellow-500" />
                      <span className="ml-1 font-medium">{product.rating}</span>
                    </div>
                    <div className="flex items-center ml-4 text-gray-500">
                      <Calendar size={16} className="mr-1" />
                      <span>Released: {new Date(product.releaseDate).toLocaleDateString()}</span>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6">{product.description}</p>

                  <div className="text-3xl font-bold text-gray-800 mb-6">
                    {formatPrice(product.price)}
                  </div>
                </div>

                <div className="mt-auto flex flex-wrap gap-3">
                  <Link
                    to="/compare"
                    className="flex-1 flex justify-center items-center gap-2 py-3 px-6 bg-white border border-blue-600 text-blue-600 font-medium rounded-lg hover:bg-blue-50 transition-colors"
                  >
                    View Comparisons
                  </Link>
                  <button
                    onClick={handleAddToComparison}
                    disabled={isSelected}
                    className={`flex-1 flex justify-center items-center gap-2 py-3 px-6 font-medium rounded-lg transition-colors ${
                      isSelected
                        ? 'bg-green-100 text-green-700 border border-green-700'
                        : 'bg-blue-600 text-white hover:bg-blue-700'
                    }`}
                  >
                    {isSelected ? (
                      <>
                        <CheckCircle size={18} />
                        Added to Compare
                      </>
                    ) : (
                      <>
                        <PlusCircle size={18} />
                        Add to Compare
                      </>
                    )}
                  </button>
                </div>

                {isUserAdmin() && (
                  <div className="mt-4">
                    {showConfirmDelete ? (
                      <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                        <p className="text-red-700 mb-2">Are you sure you want to delete this product?</p>
                        <div className="flex gap-2">
                          <button
                            onClick={handleDeleteProduct}
                            className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
                          >
                            Confirm Delete
                          </button>
                          <button
                            onClick={() => setShowConfirmDelete(false)}
                            className="bg-gray-200 text-gray-700 px-3 py-1 rounded hover:bg-gray-300"
                          >
                            Cancel
                          </button>
                        </div>
                      </div>
                    ) : (
                      <button
                        onClick={() => setShowConfirmDelete(true)}
                        className="flex items-center text-red-600 hover:text-red-800"
                      >
                        <Trash2 size={16} className="mr-1" />
                        Delete Product
                      </button>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Product Details Tabs */}
          <div className="border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-gray-200">
              {/* Specifications */}
              <div className="p-6">
                <h2 className="text-xl font-bold mb-4">Specifications</h2>
                <table className="w-full">
                  <tbody>
                    {specifications.map(({ key, value }) => (
                      <tr key={key} className="border-b border-gray-100">
                        <td className="py-2 text-gray-600">{key}</td>
                        <td className="py-2 font-medium text-gray-800">{value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Features */}
              <div className="p-6">
                <h2 className="text-xl font-bold mb-4">Key Features</h2>
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle size={18} className="text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Related Products */}
              <div className="p-6">
                <h2 className="text-xl font-bold mb-4">Compare With</h2>
                {selectedProducts.length > 0 ? (
                  <div className="space-y-4">
                    {selectedProducts
                      .filter(p => p.id !== product.id)
                      .slice(0, 3)
                      .map(p => (
                        <Link
                          key={p.id}
                          to={`/products/${p.id}`}
                          className="flex items-center p-2 rounded-lg hover:bg-gray-50"
                        >
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-12 h-12 object-cover rounded"
                          />
                          <div className="ml-3">
                            <h3 className="font-medium">{p.name}</h3>
                            <p className="text-sm text-gray-500">{formatPrice(p.price)}</p>
                          </div>
                        </Link>
                      ))}
                    <Link
                      to="/compare"
                      className="block text-center bg-blue-50 text-blue-700 py-2 rounded-lg hover:bg-blue-100 transition-colors"
                    >
                      View Comparison
                    </Link>
                  </div>
                ) : (
                  <p className="text-gray-600">
                    Select products to compare with this {product.category}.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetailPage;