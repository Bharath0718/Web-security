import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Laptop, Smartphone, Headphones, Watch, Search } from 'lucide-react';
import ProductCard from '../components/ProductCard';
import { useProducts } from '../contexts/ProductContext';

const HomePage: React.FC = () => {
  const { products, loading } = useProducts();
  const [searchQuery, setSearchQuery] = useState('');
  
  // Get featured products (top rated)
  const featuredProducts = [...products]
    .sort((a, b) => b.rating - a.rating)
    .slice(0, 4);

  // Handle search submission
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/search?q=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative bg-gradient-to-r from-blue-600 to-indigo-800 pt-24 pb-32 md:pt-32 md:pb-40"
      >
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{ 
            backgroundImage: "url('https://images.pexels.com/photos/1714208/pexels-photo-1714208.jpeg')",
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        ></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-3xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">
              Find the Perfect Tech for Your Lifestyle
            </h1>
            <p className="text-xl text-blue-100 mb-8">
              Compare and review the latest gadgets to make informed decisions for your tech needs.
            </p>
            
            {/* Search Form */}
            <form 
              onSubmit={handleSearch}
              className="relative max-w-xl mx-auto bg-white rounded-full overflow-hidden shadow-lg flex"
            >
              <input
                type="text"
                placeholder="Search for products..."
                className="w-full py-4 px-6 outline-none text-gray-700"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <button
                type="submit"
                className="bg-blue-600 text-white px-6 flex items-center justify-center hover:bg-blue-700 transition-colors"
              >
                <Search size={20} />
                <span className="ml-2 hidden md:inline">Search</span>
              </button>
            </form>
          </div>
        </div>
        
        {/* Wave Shape Divider */}
        <div className="absolute bottom-0 left-0 right-0 w-full overflow-hidden" style={{ height: '70px' }}>
          <svg 
            className="absolute bottom-0 w-full h-full" 
            viewBox="0 0 1440 70" 
            preserveAspectRatio="none"
            fill="white"
          >
            <path d="M0,70 C240,30 480,0 720,0 C960,0 1200,30 1440,70 L1440,70 L0,70 Z"></path>
          </svg>
        </div>
      </section>
      
      {/* Categories Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12">Browse by Category</h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <Link 
              to="/products?category=smartphones" 
              className="bg-blue-50 rounded-xl p-6 text-center transition-all hover:shadow-md hover:-translate-y-1"
            >
              <div className="bg-blue-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Smartphone size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800">Smartphones</h3>
            </Link>
            
            <Link 
              to="/products?category=laptops" 
              className="bg-indigo-50 rounded-xl p-6 text-center transition-all hover:shadow-md hover:-translate-y-1"
            >
              <div className="bg-indigo-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Laptop size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800">Laptops</h3>
            </Link>
            
            <Link 
              to="/products?category=headphones" 
              className="bg-teal-50 rounded-xl p-6 text-center transition-all hover:shadow-md hover:-translate-y-1"
            >
              <div className="bg-teal-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Headphones size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800">Headphones</h3>
            </Link>
            
            <Link 
              to="/products?category=smartwatches" 
              className="bg-purple-50 rounded-xl p-6 text-center transition-all hover:shadow-md hover:-translate-y-1"
            >
              <div className="bg-purple-600 text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Watch size={32} />
              </div>
              <h3 className="text-xl font-semibold text-gray-800">Smartwatches</h3>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Featured Products */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap items-center justify-between mb-12">
            <h2 className="text-3xl font-bold">Featured Products</h2>
            <Link 
              to="/products" 
              className="text-blue-600 font-medium flex items-center hover:text-blue-800"
            >
              View All
              <ArrowRight size={16} className="ml-1" />
            </Link>
          </div>
          
          {loading ? (
            <div className="text-center py-12">
              <div className="animate-spin h-12 w-12 border-t-2 border-b-2 border-blue-600 rounded-full mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading products...</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredProducts.map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>
      
      {/* Compare CTA */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-indigo-800 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Confused About Which Product to Choose?
            </h2>
            <p className="text-xl text-blue-100 mb-8">
              Use our comparison tool to see side-by-side specs and make an informed decision.
            </p>
            <Link 
              to="/compare" 
              className="inline-block bg-white text-blue-600 font-semibold px-8 py-3 rounded-full hover:bg-blue-50 transition-colors"
            >
              Compare Products
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;