import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { ArrowLeft, Save, Plus, Trash2, Upload, X } from 'lucide-react';
import { useProducts } from '../contexts/ProductContext';
import { Product } from '../types';

const ProductFormPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getProduct, createProduct, editProduct } = useProducts();
  const isEditing = !!id;
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Initialize empty product
  const emptyProduct: Omit<Product, 'id' | 'createdAt' | 'updatedAt'> = {
    name: '',
    brand: '',
    category: '',
    image: '',
    price: 0,
    rating: 0,
    releaseDate: new Date().toISOString().split('T')[0],
    specifications: {},
    features: [''],
    description: ''
  };

  // State for form
  const [formData, setFormData] = useState(emptyProduct);
  const [specKeys, setSpecKeys] = useState<string[]>([]);
  const [specValues, setSpecValues] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [imagePreview, setImagePreview] = useState<string>('');
  const [isDragging, setIsDragging] = useState(false);

  // Load product data if editing
  useEffect(() => {
    if (isEditing && id) {
      const product = getProduct(id);
      if (product) {
        setFormData({
          name: product.name,
          brand: product.brand,
          category: product.category,
          image: product.image,
          price: product.price,
          rating: product.rating,
          releaseDate: new Date(product.releaseDate).toISOString().split('T')[0],
          specifications: { ...product.specifications },
          features: [...product.features],
          description: product.description
        });
        setImagePreview(product.image);

        // Set specifications
        const keys = Object.keys(product.specifications);
        const values = keys.map(key => product.specifications[key].toString());
        setSpecKeys([...keys]);
        setSpecValues([...values]);
      } else {
        navigate('/admin');
      }
    } else {
      // Initialize with empty spec
      setSpecKeys(['']);
      setSpecValues(['']);
    }
  }, [id, isEditing, getProduct, navigate]);

  // Format price in Indian Rupees
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };

  // Handle image upload
  const handleImageUpload = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please upload an image file');
      return;
    }

    if (file.size > 5 * 1024 * 1024) { // 5MB limit
      setError('Image size should be less than 5MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setImagePreview(result);
      setFormData(prev => ({ ...prev, image: result }));
    };
    reader.readAsDataURL(file);
  };

  // Handle drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const file = e.dataTransfer.files[0];
    if (file) {
      handleImageUpload(file);
    }
  };

  // Handle text input changes
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'price' || name === 'rating') {
      setFormData({
        ...formData,
        [name]: parseFloat(value) || 0
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  // Handle specification changes
  const handleSpecKeyChange = (index: number, value: string) => {
    const newKeys = [...specKeys];
    newKeys[index] = value;
    setSpecKeys(newKeys);
  };

  const handleSpecValueChange = (index: number, value: string) => {
    const newValues = [...specValues];
    newValues[index] = value;
    setSpecValues(newValues);
  };

  const addSpecification = () => {
    setSpecKeys([...specKeys, '']);
    setSpecValues([...specValues, '']);
  };

  const removeSpecification = (index: number) => {
    const newKeys = [...specKeys];
    const newValues = [...specValues];
    newKeys.splice(index, 1);
    newValues.splice(index, 1);
    setSpecKeys(newKeys);
    setSpecValues(newValues);
  };

  // Handle feature changes
  const handleFeatureChange = (index: number, value: string) => {
    const newFeatures = [...formData.features];
    newFeatures[index] = value;
    setFormData({
      ...formData,
      features: newFeatures
    });
  };

  const addFeature = () => {
    setFormData({
      ...formData,
      features: [...formData.features, '']
    });
  };

  const removeFeature = (index: number) => {
    const newFeatures = [...formData.features];
    newFeatures.splice(index, 1);
    setFormData({
      ...formData,
      features: newFeatures
    });
  };

  // Remove image
  const handleRemoveImage = () => {
    setImagePreview('');
    setFormData(prev => ({ ...prev, image: '' }));
  };

  // Form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // Validate form
      if (!formData.name || !formData.brand || !formData.category) {
        setError('Please fill in all required fields');
        setLoading(false);
        return;
      }

      if (!formData.image) {
        setError('Please upload a product image');
        setLoading(false);
        return;
      }

      // Create specifications object
      const specifications: Record<string, string | number> = {};
      specKeys.forEach((key, index) => {
        if (key && specValues[index]) {
          // Try to convert to number if possible
          const value = specValues[index];
          const numValue = parseFloat(value);
          specifications[key] = !isNaN(numValue) ? numValue : value;
        }
      });

      // Filter out empty features
      const features = formData.features.filter(feature => feature.trim() !== '');

      const productData = {
        ...formData,
        specifications,
        features
      };

      if (isEditing && id) {
        await editProduct(id, productData);
      } else {
        await createProduct(productData);
      }

      navigate('/admin');
    } catch (err) {
      setError('An error occurred while saving the product');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16 pb-12">
      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <Link 
            to="/admin" 
            className="inline-flex items-center text-blue-600 hover:text-blue-800"
          >
            <ArrowLeft size={16} className="mr-1" />
            Back to Admin
          </Link>
        </div>

        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 bg-gradient-to-r from-blue-600 to-indigo-800 text-white">
            <h1 className="text-2xl font-bold">
              {isEditing ? 'Edit Product' : 'Add New Product'}
            </h1>
          </div>

          <form onSubmit={handleSubmit} className="p-6">
            {error && (
              <div className="mb-6 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Basic Information */}
              <div>
                <h2 className="text-lg font-semibold mb-4">Basic Information</h2>
                
                <div className="space-y-4">
                  {/* Image Upload */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Product Image *
                    </label>
                    <div
                      className={`border-2 border-dashed rounded-lg p-4 text-center ${
                        isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
                      }`}
                      onDragOver={handleDragOver}
                      onDragLeave={handleDragLeave}
                      onDrop={handleDrop}
                    >
                      {imagePreview ? (
                        <div className="relative">
                          <img
                            src={imagePreview}
                            alt="Preview"
                            className="max-h-48 mx-auto rounded-lg"
                          />
                          <button
                            type="button"
                            onClick={handleRemoveImage}
                            className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600 transition-colors"
                          >
                            <X size={16} />
                          </button>
                        </div>
                      ) : (
                        <div>
                          <input
                            type="file"
                            ref={fileInputRef}
                            className="hidden"
                            accept="image/*"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) handleImageUpload(file);
                            }}
                          />
                          <button
                            type="button"
                            onClick={() => fileInputRef.current?.click()}
                            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                          >
                            <Upload size={16} className="mr-2" />
                            Choose Image
                          </button>
                          <p className="mt-2 text-sm text-gray-500">
                            or drag and drop an image here
                          </p>
                          <p className="mt-1 text-xs text-gray-400">
                            PNG, JPG up to 5MB
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Product Name *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Brand *
                    </label>
                    <input
                      type="text"
                      name="brand"
                      value={formData.brand}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Category *
                    </label>
                    <select
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select a category</option>
                      <option value="Smartphones">Smartphones</option>
                      <option value="Laptops">Laptops</option>
                      <option value="Tablets">Tablets</option>
                      <option value="Headphones">Headphones</option>
                      <option value="Smartwatches">Smartwatches</option>
                      <option value="Cameras">Cameras</option>
                      <option value="TVs">TVs</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Price (₹) *
                    </label>
                    <input
                      type="number"
                      name="price"
                      value={formData.price}
                      onChange={handleInputChange}
                      min="0"
                      step="1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                    {formData.price > 0 && (
                      <p className="mt-1 text-sm text-gray-500">
                        Formatted: {formatPrice(formData.price)}
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Rating (0-5) *
                    </label>
                    <input
                      type="number"
                      name="rating"
                      value={formData.rating}
                      onChange={handleInputChange}
                      min="0"
                      max="5"
                      step="0.1"
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Release Date *
                    </label>
                    <input
                      type="date"
                      name="releaseDate"
                      value={formData.releaseDate}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                </div>
              </div>
              
              {/* Specifications & Features */}
              <div>
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold">Specifications</h2>
                    <button
                      type="button"
                      onClick={addSpecification}
                      className="text-sm bg-blue-50 text-blue-600 px-3 py-1 rounded-full hover:bg-blue-100 transition-colors flex items-center"
                    >
                      <Plus size={16} className="mr-1" />
                      Add
                    </button>
                  </div>
                  
                  {specKeys.map((key, index) => (
                    <div key={index} className="flex gap-3 mb-3">
                      <div className="flex-1">
                        <input
                          type="text"
                          value={key}
                          onChange={(e) => handleSpecKeyChange(index, e.target.value)}
                          placeholder="Spec name (e.g., processor)"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <div className="flex-1">
                        <input
                          type="text"
                          value={specValues[index]}
                          onChange={(e) => handleSpecValueChange(index, e.target.value)}
                          placeholder="Value (e.g., A15 Bionic)"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeSpecification(index)}
                        className="text-red-500 hover:text-red-700"
                        disabled={specKeys.length <= 1}
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))}
                </div>
                
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold">Features</h2>
                    <button
                      type="button"
                      onClick={addFeature}
                      className="text-sm bg-blue-50 text-blue-600 px-3 py-1 rounded-full hover:bg-blue-100 transition-colors flex items-center"
                    >
                      <Plus size={16} className="mr-1" />
                      Add
                    </button>
                  </div>
                  
                  {formData.features.map((feature, index) => (
                    <div key={index} className="flex gap-3 mb-3">
                      <div className="flex-1">
                        <input
                          type="text"
                          value={feature}
                          onChange={(e) => handleFeatureChange(index, e.target.value)}
                          placeholder="Feature description"
                          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFeature(index)}
                        className="text-red-500 hover:text-red-700"
                        disabled={formData.features.length <= 1}
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Product Description */}
            <div className="mb-6">
              <label className="block text-lg font-semibold mb-2">
                Product Description *
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleInputChange}
                rows={5}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Detailed description of the product..."
                required
              ></textarea>
            </div>
            
            {/* Form Actions */}
            <div className="flex items-center justify-end space-x-3">
              <Link
                to="/admin"
                className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                Cancel
              </Link>
              <button
                type="submit"
                disabled={loading}
                className="flex items-center px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-70"
              >
                {loading ? (
                  <>
                    <div className="animate-spin h-4 w-4 border-t-2 border-b-2 border-white rounded-full mr-2"></div>
                    Saving...
                  </>
                ) : (
                  <>
                    <Save size={18} className="mr-2" />
                    {isEditing ? 'Update Product' : 'Create Product'}
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProductFormPage;