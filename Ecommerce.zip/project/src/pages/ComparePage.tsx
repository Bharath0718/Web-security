import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  X, 
  PlusCircle, 
  Star, 
  Calendar, 
  CheckCircle, 
  XCircle
} from 'lucide-react';
import { useProducts } from '../contexts/ProductContext';
import ProductCard from '../components/ProductCard';

const ComparePage: React.FC = () => {
  const { 
    products, 
    selectedProducts, 
    removeFromComparison, 
    clearComparison, 
    addToComparison 
  } = useProducts();
  const [showAddModal, setShowAddModal] = useState(false);
  
  // Get products that are not selected for comparison
  const availableProducts = products.filter(
    product => !selectedProducts.some(p => p.id === product.id)
  );

  // Get all unique specification keys from selected products
  const allSpecKeys = selectedProducts.length > 0
    ? [...new Set(selectedProducts.flatMap(product => Object.keys(product.specifications)))]
        .sort((a, b) => a.localeCompare(b))
    : [];

  // Format specification key for display
  const formatSpecKey = (key: string) => {
    return key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1');
  };

  // Check if all products have the same value for a spec
  const allSameValue = (key: string) => {
    if (selectedProducts.length <= 1) return false;
    
    const values = selectedProducts.map(p => p.specifications[key]);
    return values.every(v => v === values[0]);
  };

  // Get the value for a spec key from a product
  const getSpecValue = (product: any, key: string) => {
    return product.specifications[key] || '—';
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16 pb-12">
      <div className="container mx-auto px-4 py-8">
        <div className="bg-white rounded-xl shadow-md overflow-hidden">
          <div className="p-6 bg-gradient-to-r from-blue-600 to-indigo-800 text-white">
            <div className="flex flex-wrap items-center justify-between">
              <h1 className="text-2xl md:text-3xl font-bold mb-2 md:mb-0">
                Product Comparison
              </h1>
              {selectedProducts.length > 0 && (
                <button
                  onClick={clearComparison}
                  className="bg-white bg-opacity-20 hover:bg-opacity-30 text-white py-1 px-4 rounded-full text-sm transition-colors"
                >
                  Clear All
                </button>
              )}
            </div>
          </div>

          {selectedProducts.length === 0 ? (
            <div className="p-12 text-center">
              <p className="text-xl text-gray-600 mb-4">
                No products selected for comparison
              </p>
              <p className="text-gray-500 mb-6">
                Browse our products and add items to compare their features and specifications
              </p>
              <Link
                to="/products"
                className="inline-block bg-blue-600 text-white font-medium px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Browse Products
              </Link>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-max">
                <thead>
                  <tr className="bg-gray-50">
                    <th className="p-4 text-left text-gray-600 font-medium w-48 sticky left-0 bg-gray-50 z-10">
                      Product
                    </th>
                    {selectedProducts.map(product => (
                      <th key={product.id} className="p-4 text-center min-w-[220px]">
                        <div className="relative">
                          <button
                            onClick={() => removeFromComparison(product.id)}
                            className="absolute -top-2 -right-2 bg-gray-200 rounded-full p-1 text-gray-500 hover:bg-gray-300 transition-colors"
                          >
                            <X size={16} />
                          </button>
                          <div className="h-36 flex items-center justify-center mb-2">
                            <img
                              src={product.image}
                              alt={product.name}
                              className="max-h-full max-w-[180px] object-contain"
                            />
                          </div>
                          <Link
                            to={`/products/${product.id}`}
                            className="block text-blue-600 hover:text-blue-800 font-semibold text-lg mb-1"
                          >
                            {product.name}
                          </Link>
                          <div className="text-gray-600 mb-1">{product.brand}</div>
                          <div className="flex items-center justify-center mb-2">
                            <Star size={16} className="text-yellow-500 fill-current" />
                            <span className="ml-1">{product.rating}</span>
                          </div>
                          <div className="text-xl font-bold">${product.price}</div>
                        </div>
                      </th>
                    ))}
                    {selectedProducts.length < 3 && (
                      <th className="p-4 text-center min-w-[220px]">
                        <button
                          onClick={() => setShowAddModal(true)}
                          className="flex flex-col items-center justify-center h-64 w-full border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors"
                        >
                          <PlusCircle size={32} className="text-gray-400 mb-2" />
                          <span className="text-gray-600">Add Product</span>
                        </button>
                      </th>
                    )}
                  </tr>
                </thead>
                <tbody>
                  {/* Basic details */}
                  <tr>
                    <td className="p-4 font-medium text-gray-700 bg-gray-50 sticky left-0 z-10">
                      Category
                    </td>
                    {selectedProducts.map(product => (
                      <td key={product.id} className="p-4 text-center border-t">
                        {product.category}
                      </td>
                    ))}
                    {selectedProducts.length < 3 && <td className="p-4 border-t"></td>}
                  </tr>
                  <tr>
                    <td className="p-4 font-medium text-gray-700 bg-gray-50 sticky left-0 z-10">
                      Release Date
                    </td>
                    {selectedProducts.map(product => (
                      <td key={product.id} className="p-4 text-center border-t">
                        <div className="flex items-center justify-center text-gray-600">
                          <Calendar size={16} className="mr-1" />
                          {new Date(product.releaseDate).toLocaleDateString()}
                        </div>
                      </td>
                    ))}
                    {selectedProducts.length < 3 && <td className="p-4 border-t"></td>}
                  </tr>

                  {/* Specifications */}
                  <tr className="bg-gray-100">
                    <td colSpan={selectedProducts.length + 2} className="p-3 font-bold text-gray-700">
                      Specifications
                    </td>
                  </tr>
                  {allSpecKeys.map(key => (
                    <tr key={key}>
                      <td className="p-4 font-medium text-gray-700 bg-gray-50 sticky left-0 z-10">
                        {formatSpecKey(key)}
                      </td>
                      {selectedProducts.map(product => {
                        const value = getSpecValue(product, key);
                        const isSame = allSameValue(key);
                        
                        return (
                          <td 
                            key={product.id} 
                            className={`p-4 text-center border-t ${
                              isSame ? 'text-gray-500' : 'font-medium'
                            }`}
                          >
                            {value}
                          </td>
                        );
                      })}
                      {selectedProducts.length < 3 && <td className="p-4 border-t"></td>}
                    </tr>
                  ))}

                  {/* Features */}
                  <tr className="bg-gray-100">
                    <td colSpan={selectedProducts.length + 2} className="p-3 font-bold text-gray-700">
                      Key Features
                    </td>
                  </tr>
                  {selectedProducts.length > 0 && 
                    Math.max(...selectedProducts.map(p => p.features.length)) > 0 && 
                    Array.from({ 
                      length: Math.max(...selectedProducts.map(p => p.features.length)) 
                    }).map((_, index) => (
                      <tr key={index}>
                        <td className="p-4 font-medium text-gray-700 bg-gray-50 sticky left-0 z-10">
                          Feature {index + 1}
                        </td>
                        {selectedProducts.map(product => (
                          <td key={product.id} className="p-4 text-center border-t">
                            {product.features[index] ? (
                              <div className="flex items-center">
                                <CheckCircle size={16} className="text-green-500 mr-2 flex-shrink-0" />
                                <span>{product.features[index]}</span>
                              </div>
                            ) : (
                              <div className="flex items-center text-gray-400">
                                <XCircle size={16} className="mr-2 flex-shrink-0" />
                                <span>Not available</span>
                              </div>
                            )}
                          </td>
                        ))}
                        {selectedProducts.length < 3 && <td className="p-4 border-t"></td>}
                      </tr>
                    ))
                  }
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Add Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl shadow-xl w-full max-w-3xl max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-xl font-bold">Add Product to Compare</h2>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-gray-500 hover:text-gray-700"
              >
                <X size={24} />
              </button>
            </div>
            <div className="p-4 overflow-y-auto max-h-[calc(80vh-120px)]">
              {availableProducts.length === 0 ? (
                <p className="text-center py-8 text-gray-600">
                  All products have been added to comparison
                </p>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                  {availableProducts.map(product => (
                    <div
                      key={product.id}
                      className="border rounded-lg overflow-hidden hover:shadow-md transition-shadow cursor-pointer"
                      onClick={() => {
                        addToComparison(product.id);
                        setShowAddModal(false);
                      }}
                    >
                      <ProductCard product={product} isCompact />
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="p-4 border-t">
              <button
                onClick={() => setShowAddModal(false)}
                className="w-full py-2 px-4 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ComparePage;