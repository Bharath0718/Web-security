export interface User {
  id: string;
  email: string;
  password: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface Product {
  id: string;
  name: string;
  brand: string;
  category: string;
  image: string;
  price: number;
  rating: number;
  releaseDate: string;
  specifications: {
    [key: string]: string | number;
  };
  features: string[];
  description: string;
  createdAt: string;
  updatedAt: string;
}