import bcrypt from 'bcryptjs';
import { v4 as uuidv4 } from 'uuid';
import { User } from '../types';

// Salt rounds for bcrypt
const SALT_ROUNDS = 10;

// Store users in localStorage
const USERS_STORAGE_KEY = 'tech_hub_users';
const SESSION_STORAGE_KEY = 'tech_hub_session';

// Initialize with an admin user if no users exist
export const initializeUsers = (): void => {
  const existingUsers = localStorage.getItem(USERS_STORAGE_KEY);
  
  if (!existingUsers) {
    const adminPassword = bcrypt.hashSync('admin123', SALT_ROUNDS);
    const initialUsers: User[] = [
      {
        id: uuidv4(),
        email: 'admin@techhub.com',
        password: adminPassword,
        role: 'admin',
        createdAt: new Date().toISOString(),
      }
    ];
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(initialUsers));
  }
};

// Get all users
export const getUsers = (): User[] => {
  const users = localStorage.getItem(USERS_STORAGE_KEY);
  return users ? JSON.parse(users) : [];
};

// Register a new user
export const registerUser = async (email: string, password: string): Promise<User | null> => {
  try {
    const users = getUsers();
    
    // Check if user already exists
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
      return null;
    }
    
    // Hash password
    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);
    
    // Create new user
    const newUser: User = {
      id: uuidv4(),
      email,
      password: hashedPassword,
      role: 'user', // Default role
      createdAt: new Date().toISOString(),
    };
    
    // Save to localStorage
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify([...users, newUser]));
    
    return newUser;
  } catch (error) {
    console.error('Error registering user:', error);
    return null;
  }
};

// Login user
export const loginUser = async (email: string, password: string): Promise<User | null> => {
  try {
    const users = getUsers();
    const user = users.find(user => user.email === email);
    
    if (!user) {
      return null;
    }
    
    const isPasswordValid = await bcrypt.compare(password, user.password);
    
    if (!isPasswordValid) {
      return null;
    }
    
    // Create session
    const sessionData = {
      userId: user.id,
      email: user.email,
      role: user.role,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // 24 hour expiry
    };
    
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(sessionData));
    
    return user;
  } catch (error) {
    console.error('Error logging in:', error);
    return null;
  }
};

// Logout user
export const logoutUser = (): void => {
  localStorage.removeItem(SESSION_STORAGE_KEY);
};

// Check if user is logged in
export const isAuthenticated = (): boolean => {
  const session = localStorage.getItem(SESSION_STORAGE_KEY);
  
  if (!session) {
    return false;
  }
  
  const sessionData = JSON.parse(session);
  const expiresAt = new Date(sessionData.expiresAt);
  
  // Check if session is expired
  if (expiresAt < new Date()) {
    localStorage.removeItem(SESSION_STORAGE_KEY);
    return false;
  }
  
  return true;
};

// Get current user
export const getCurrentUser = (): { userId: string; email: string; role: string } | null => {
  if (!isAuthenticated()) {
    return null;
  }
  
  const session = localStorage.getItem(SESSION_STORAGE_KEY);
  return session ? JSON.parse(session) : null;
};

// Check if user is admin
export const isAdmin = (): boolean => {
  const currentUser = getCurrentUser();
  return currentUser?.role === 'admin';
};