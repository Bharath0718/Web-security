import { v4 as uuidv4 } from 'uuid';
import { Product } from '../types';

// Storage key for products
const PRODUCTS_STORAGE_KEY = 'tech_hub_products';

// Sample products data
const sampleProducts: Product[] = [
  // Vivo Smartphones
  {
    id: uuidv4(),
    name: 'Vivo V29 Pro',
    brand: 'Vivo',
    category: 'Smartphones',
    image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
    price: 39999,
    rating: 4.5,
    releaseDate: '2023-10-10',
    specifications: {
      processor: 'MediaTek Dimensity 8200',
      ram: '12GB',
      storage: '256GB',
      display: '6.78-inch AMOLED',
      camera: '50MP + 12MP + 8MP',
      battery: '4600mAh',
      os: 'Funtouch OS 13',
      weight: '188g'
    },
    features: [
      'Smart Aura Light',
      '80W FlashCharge',
      'Wedding Portrait Mode',
      'In-display fingerprint',
      'Curved Display'
    ],
    description: 'The Vivo V29 Pro features a premium curved display and advanced camera system with Smart Aura Light for perfect portraits.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: uuidv4(),
    name: 'Vivo X90 Pro+',
    brand: 'Vivo',
    category: 'Smartphones',
    image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
    price: 79999,
    rating: 4.7,
    releaseDate: '2023-09-15',
    specifications: {
      processor: 'Snapdragon 8 Gen 2',
      ram: '12GB',
      storage: '512GB',
      display: '6.78-inch LTPO AMOLED',
      camera: '50MP + 50MP + 48MP + 64MP',
      battery: '4700mAh',
      os: 'Funtouch OS 13',
      weight: '195g'
    },
    features: [
      'ZEISS Optics',
      '120W FlashCharge',
      'V2 Imaging Chip',
      'IP68 rating',
      '1-inch sensor'
    ],
    description: 'Vivo X90 Pro+ delivers exceptional photography with ZEISS optics and advanced V2 imaging chip.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: uuidv4(),
    name: 'Redmi Note 13 Pro+ 5G',
    brand: 'Redmi',
    category: 'Smartphones',
    image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
    price: 29999,
    rating: 4.4,
    releaseDate: '2024-01-15',
    specifications: {
      processor: 'Dimensity 7200 Ultra',
      ram: '8GB',
      storage: '256GB',
      display: '6.67-inch AMOLED',
      camera: '200MP + 8MP + 2MP',
      battery: '5000mAh',
      os: 'MIUI 14',
      weight: '187g'
    },
    features: [
      '120W HyperCharge',
      'IP68 rating',
      '200MP camera',
      'Dolby Vision',
      'Dolby Atmos'
    ],
    description: 'The Redmi Note 13 Pro+ 5G features a 200MP camera and blazing-fast 120W charging.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: uuidv4(),
    name: 'OPPO Find N3 Flip',
    brand: 'OPPO',
    category: 'Smartphones',
    image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
    price: 94999,
    rating: 4.6,
    releaseDate: '2023-10-20',
    specifications: {
      processor: 'Dimensity 9200',
      ram: '12GB',
      storage: '256GB',
      display: '6.8-inch AMOLED + 3.26-inch Cover',
      camera: '50MP + 48MP + 32MP',
      battery: '4300mAh',
      os: 'ColorOS 13',
      weight: '198g'
    },
    features: [
      'FlexForm Mode',
      '44W SUPERVOOC',
      'Hasselblad Camera',
      'Gapless Design',
      'Multi-Angle Hinge'
    ],
    description: 'OPPO Find N3 Flip combines style with functionality in a premium foldable form factor.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: uuidv4(),
    name: 'ASUS ROG Phone 7 Ultimate',
    brand: 'ASUS',
    category: 'Smartphones',
    image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
    price: 99999,
    rating: 4.8,
    releaseDate: '2023-07-10',
    specifications: {
      processor: 'Snapdragon 8 Gen 2',
      ram: '16GB',
      storage: '512GB',
      display: '6.78-inch AMOLED',
      camera: '50MP + 13MP + 8MP',
      battery: '6000mAh',
      os: 'ROG UI',
      weight: '239g'
    },
    features: [
      'AeroActive Portal',
      'GameCool 7',
      'ROG Vision',
      'Dual USB-C',
      'Kunai 3 Gamepad'
    ],
    description: 'The ultimate gaming phone with innovative cooling system and gaming accessories support.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: uuidv4(),
    name: 'iQOO 12 Pro',
    brand: 'iQOO',
    category: 'Smartphones',
    image: 'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg',
    price: 59999,
    rating: 4.7,
    releaseDate: '2023-12-12',
    specifications: {
      processor: 'Snapdragon 8 Gen 3',
      ram: '12GB',
      storage: '256GB',
      display: '6.78-inch LTPO AMOLED',
      camera: '50MP + 50MP + 64MP',
      battery: '5100mAh',
      os: 'Funtouch OS 14',
      weight: '205g'
    },
    features: [
      '144Hz Display',
      '120W FlashCharge',
      'V3 Chip',
      'Vapor Chamber',
      'Monster Touch'
    ],
    description: 'iQOO 12 Pro delivers flagship performance with advanced gaming features and fast charging.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  },
  {
    id: uuidv4(),
    name: 'ASUS ROG Strix SCAR 16',
    brand: 'ASUS',
    category: 'Laptops',
    image: 'https://images.pexels.com/photos/303383/pexels-photo-303383.jpeg',
    price: 249999,
    rating: 4.8,
    releaseDate: '2024-01-05',
    specifications: {
      processor: 'Intel Core i9-14900HX',
      ram: '32GB DDR5',
      storage: '2TB NVMe SSD',
      display: '16-inch QHD+ 240Hz',
      graphics: 'NVIDIA RTX 4090',
      battery: 'Up to 8 hours',
      ports: 'Thunderbolt 4, HDMI 2.1',
      weight: '2.5kg'
    },
    features: [
      'ROG Nebula HDR',
      'MUX Switch',
      'Liquid Metal Cooling',
      'Per-key RGB',
      'Xbox Game Pass'
    ],
    description: 'The ultimate gaming laptop with top-tier performance and advanced cooling system.',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  }
];

export const initializeProducts = (): void => {
  const existingProducts = localStorage.getItem(PRODUCTS_STORAGE_KEY);
  
  if (!existingProducts) {
    localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(sampleProducts));
  }
};

export const getAllProducts = (): Product[] => {
  const products = localStorage.getItem(PRODUCTS_STORAGE_KEY);
  return products ? JSON.parse(products) : [];
};

export const getProductById = (id: string): Product | undefined => {
  const products = getAllProducts();
  return products.find(product => product.id === id);
};

export const addProduct = (product: Omit<Product, 'id' | 'createdAt' | 'updatedAt'>): Product => {
  const products = getAllProducts();
  
  const newProduct: Product = {
    ...product,
    id: uuidv4(),
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify([...products, newProduct]));
  
  return newProduct;
};

export const updateProduct = (id: string, updates: Partial<Product>): Product | null => {
  const products = getAllProducts();
  const productIndex = products.findIndex(product => product.id === id);
  
  if (productIndex === -1) {
    return null;
  }
  
  const updatedProduct: Product = {
    ...products[productIndex],
    ...updates,
    updatedAt: new Date().toISOString()
  };
  
  products[productIndex] = updatedProduct;
  localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products));
  
  return updatedProduct;
};

export const deleteProduct = (id: string): boolean => {
  const products = getAllProducts();
  const updatedProducts = products.filter(product => product.id !== id);
  
  if (updatedProducts.length === products.length) {
    return false;
  }
  
  localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(updatedProducts));
  return true;
};

export const getProductsByCategory = (category: string): Product[] => {
  const products = getAllProducts();
  return products.filter(product => product.category.toLowerCase() === category.toLowerCase());
};

export const searchProducts = (query: string): Product[] => {
  if (!query.trim()) {
    return getAllProducts();
  }
  
  const products = getAllProducts();
  const lowercaseQuery = query.toLowerCase();
  
  return products.filter(product => 
    product.name.toLowerCase().includes(lowercaseQuery) ||
    product.brand.toLowerCase().includes(lowercaseQuery) ||
    product.category.toLowerCase().includes(lowercaseQuery) ||
    product.description.toLowerCase().includes(lowercaseQuery)
  );
};