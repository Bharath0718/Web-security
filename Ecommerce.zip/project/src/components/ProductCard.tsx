import React from 'react';
import { Link } from 'react-router-dom';
import { Star, ArrowRight, PlusCircle } from 'lucide-react';
import { Product } from '../types';
import { useProducts } from '../contexts/ProductContext';

interface ProductCardProps {
  product: Product;
  isCompact?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, isCompact = false }) => {
  const { addToComparison, selectedProducts, error, clearError } = useProducts();

  const isSelected = selectedProducts.some(p => p.id === product.id);

  const handleAddToComparison = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToComparison(product.id);
    
    // Clear error after 3 seconds if there is one
    if (error) {
      setTimeout(() => {
        clearError();
      }, 3000);
    }
  };

  // Format price in Indian Rupees
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(price);
  };

  // Truncate description for compact view
  const truncateDescription = (text: string, length: number) => {
    if (text.length <= length) return text;
    return text.substring(0, length) + '...';
  };

  if (isCompact) {
    return (
      <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform hover:shadow-lg hover:-translate-y-1">
        <Link to={`/products/${product.id}`}>
          <div className="h-36 overflow-hidden">
            <img 
              src={product.image} 
              alt={product.name} 
              className="w-full h-full object-cover"
            />
          </div>
          <div className="p-3">
            <h3 className="font-bold text-gray-800 truncate">{product.name}</h3>
            <p className="text-sm text-gray-500">{product.brand}</p>
            <div className="flex items-center mt-1">
              <span className="font-bold text-gray-800">{formatPrice(product.price)}</span>
              <div className="flex items-center ml-auto">
                <Star size={16} className="text-yellow-500 fill-current" />
                <span className="text-sm ml-1">{product.rating}</span>
              </div>
            </div>
          </div>
        </Link>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden transition-all hover:shadow-xl">
      <Link to={`/products/${product.id}`}>
        <div className="h-48 overflow-hidden">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-full object-cover transition-transform hover:scale-105"
          />
        </div>
        <div className="p-5">
          <h3 className="text-xl font-bold text-gray-800 mb-1">{product.name}</h3>
          <p className="text-gray-500 mb-2">{product.brand} · {product.category}</p>
          
          <div className="flex items-center mb-3">
            <div className="flex items-center">
              <Star size={18} className="text-yellow-500 fill-current" />
              <span className="ml-1 font-medium">{product.rating}</span>
            </div>
            <span className="mx-2 text-gray-400">|</span>
            <span className="text-xl font-bold text-gray-800">{formatPrice(product.price)}</span>
          </div>
          
          <p className="text-gray-600 mb-4">
            {truncateDescription(product.description, 100)}
          </p>
          
          <div className="flex items-center justify-between">
            <div 
              className="text-blue-600 font-medium flex items-center hover:text-blue-800 transition-colors"
            >
              View Details
              <ArrowRight size={16} className="ml-1" />
            </div>
            
            <button 
              onClick={handleAddToComparison}
              disabled={isSelected}
              className={`flex items-center px-3 py-1 rounded-full text-sm ${
                isSelected 
                  ? 'bg-green-100 text-green-700 cursor-default' 
                  : 'bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors'
              }`}
            >
              <PlusCircle size={16} className="mr-1" />
              {isSelected ? 'Added' : 'Compare'}
            </button>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;